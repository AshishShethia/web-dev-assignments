Tree Trips is an online website which is focused on helping the users find places to stay at while they travel to a new place. It filters the places based on the user requests and finds a best place to book in the span of seconds. 

Currently we have created the landing page of our website as well as the login/sign up page. 
The 10+ bootstrap components which we used are as followed:-
Nav: this is used for all the different navbar components.
Navbar: The navbar component is used to add the logo, dropdown list, as well the links to the login/signup page and in future there will be other page links added here. 

Form: We have used the basic form component to make the login section in our project. 

Alert: This component is added in order to give an alert message for when a user submits the form or for other alerts such as incorrect email id or password, etc.  

Toast: this is used to make a customised alert message for the users.

Modal: It is used the same way to add a user notification or a custom content for the website. 

Carousel: This component is added for the different images of the hotels/places which the users can view before booking one. 

Dropdown: This component is added for the dropdown list of other links to different web pages. 

Button: Various buttons are added on the website for different functions. 

Card: It is added for good display and to customize the different sections of the website and make the design of the website attractive.

Close button: This component is added to dismiss the alerts of the modals. 

Footer: Footer component is also added in the website. 



