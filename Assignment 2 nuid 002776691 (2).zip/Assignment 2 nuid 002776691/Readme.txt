Readme 
A Professional Portfolio using html and css

Tags Used 

1) Icon link used for Favicon 

2) Ul/Li tags used for navbar

3) Icon i tag used for search bar icon,person,facebook,email,contact icons

4) H2 tag used for heading Best Mobiles and best consoles 

5) Div tags used for conatiner and shadow box

6) a tag used to navigate to feedack form also it is used for redirecting the user to official amazon page for their product
	where they can review,check price,colours and other details about thier product

7) img tag used for images 

8) main tag is used to display to main content

9) Footer tag is used for contact me information

10) Float and absolute properties are used for placement of the images

11) Transition and transform are used to give a simple effect to the image 

12) Different hover styles are used to make the website fun 

13) cards are used for image gallery 

14) Tel and mailto are used to redirect user to contact Me

15) The websitye is made responsive for all users


