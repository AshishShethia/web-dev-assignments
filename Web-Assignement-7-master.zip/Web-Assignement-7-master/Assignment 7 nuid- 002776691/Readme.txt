Variables- this are used for the themes color of project and font style
custom properties- are used to resuse the same css throughout
nesting -Sass makes easier and less redundant by allowing property declarations to be nested.
interpolation - we can interpolate entire property name and can be used to replace words
mixin function - The @mixin directive lets you create CSS code that is to be reused throughout the website.
Placeholder Selectors - In Sass as in CSS, property declarations define how elements that match a selector are styled
