Readme 

A simple website for an electronics business 

Tags used 

1) Icon link used for Favicon 

2) Ul/Li tags used for navbar

3) Icon i tag used for search bar icon,person,facebook,email,contact icons

4) H2 tag used for heading Best Mobiles and best consoles 

5) Div tags used for conatiner and shadow box

6) a tag used to navigate to feedack form also it is used for redirecting the user to official amazon page for their product
	where they can review,check price,colours and other details about thier product

7) img tag used for images 

8) footer tag is used 

9) input form tag used for Feedback form 

10) Table tag used to collect the feedback of people



