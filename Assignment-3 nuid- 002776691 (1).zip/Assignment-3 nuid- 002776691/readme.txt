Readme 
Assignment 3 using java script

Tags Used 

tr use for table row
th used for table head 
td used for table data 

on click function used for clickable events
 external css and java script linked 

create element used to add rows

getelementbyid used to fetch id 
deleterow used to delete rows
event listsner used to handle multiple events
