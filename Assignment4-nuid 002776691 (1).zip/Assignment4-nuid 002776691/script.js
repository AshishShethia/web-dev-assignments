// function addData(el) {
//     alert("submit");
//     var table = document.getElementById('list');
//     var tr = table.insertRow();
//     el.form.querySelectorAll('input').forEach(function(el) {
//       var cell = tr.appendChild(document.createElement('td'));
//       cell.textContent = el.value;
//     });
//   }




// var list1 = [];
// 		var list2 = [];
// 		var list3 = [];
// 		var list4 = [];

// 		var n = 1;
// 		var x = 0;

// var submitbtn = document.getElementById("myBtn");
// submitbtn.addEventListener("click", submitFunction);
// submitbtn.addEventListener("click", AddRow);


  
let messages = [];



		function AddRow(event){
      event.preventDefault()

      alert("ADD ROW");

      var list1 = [];
      var list2 = [];
      var list3 = [];
      var list4 = [];
      var list5 = [];
      var list6 = [];
      var list7 = [];
      var list8 = [];
      var list9 = [];
      var list10 = [];
      var list11= [];
      var list12 = [];
      

      var n = 1;
      var x = 0;

			var AddRown = document.getElementById('list');
			var NewRow = AddRown.insertRow(n);

      
      // function displayRadioValue() {
        var ele = document.getElementsByName("title")
          
        for(i = 0; i < ele.length; i++) {
            if(ele[i].checked){
              list1[x] = ele[i].value
            }
           
        }
    // }

			// list1[x] = document.getElementsByClassName("rad").value;
			list2[x] = document.getElementById("firstName").value;
			list3[x] = document.getElementById("lastName").value;
			list4[x] = document.getElementById("emailId").value;
			list5[x] = document.getElementById("phoneNumber").value;

			list6[x] = document.getElementById("streetAddress1").value;
			list7[x] = document.getElementById("streetAddress2").value;
			list8[x] = document.getElementById("city").value;
			list9[x] = document.getElementById("state").value;
			list10[x] = document.getElementById("zipcode").value;
      
			// list11[x] = document.getElementById("").value;
			list12[x] = document.getElementById("comments").value;
			

      var ele2 = document.getElementsByName("source")
          
      for(i = 0; i < ele2.length; i++) {
          if(ele2[i].checked){
            list11[x] = ele2[i].value
          }
         
      }




			var cel1 = NewRow.insertCell();
			var cel2 = NewRow.insertCell(1);
			var cel3 = NewRow.insertCell(2);
			var cel4 = NewRow.insertCell(3);
			var cel5 = NewRow.insertCell(4);

			var cel6 = NewRow.insertCell(5);
			var cel7 = NewRow.insertCell(6);
			var cel8 = NewRow.insertCell(7);
			var cel9 = NewRow.insertCell(8);
			var cel10 = NewRow.insertCell(9);
			var cel11 = NewRow.insertCell(10);
			var cel12 = NewRow.insertCell(11);
			


			cel1.innerHTML = list1[x];
			cel2.innerHTML = list2[x];
			cel3.innerHTML = list3[x];
			cel4.innerHTML = list4[x];
			cel5.innerHTML = list5[x];
			cel6.innerHTML = list6[x];
			cel7.innerHTML = list7[x];
			cel8.innerHTML = list8[x];
			cel9.innerHTML = list9[x];
			cel10.innerHTML = list10[x];
			cel11.innerHTML = list11[x];
			cel12.innerHTML = list12[x];
			

      var valCheck =  document.getElementById('newLabelText');
      if (typeof(valCheck) != 'undefined' && valCheck != null)
      {
        // Exists.
        // Setting col name
        // let tp = document.getElementById('firstRowHeader')
        // let newcol = document.createElement('td')
        // let newcolval = document.createTextNode('Game')
        // newcol.appendChild(newcolval)
        // tp.appendChild(newcol)

        // Setting vinput value
        var list13 = [];
        list13[x] = valCheck.value;
        var cel13 = NewRow.insertCell(12);
        cel13.innerHTML = list13[x];
      }


			n++;
			x++;
		}



// function numbervalidation(){
//   var phone = document.getElementById("phoneNumber").value;
//   regexPhone = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
//   var form = document.getElementById("form");
//   var text1 = document.getElementById("text1");


//   if(phone != regexPhone) {
//     alert("sucess");
//     form.classList.add("valid");
//     form.classList.remove("Invalid");
//     text1.innerHTML = "Your Email Address is Valid";
//     text1.style.color = "#00ff00";
//     return true;  
//   }
//   else {
//     alert("fail");
//     form.classList.remove("valid");
//     form.classList.remove("invalid");
//     text.innerHTML = "Please Enter Valid Email";
//     text.style.color = "#ff0000";
//     return false;
//   }



// }


function phonenumber() {
  // alert("fyu");
  var phoneno = document.getElementById("phoneNumber");
  var phonetext = document.getElementById("phonetext");
  var form = document.getElementById("form");


  var phoneRegex = /^\(?((\+[0-9]*)?[-. ])?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;

  if(phoneno.value.match(phoneRegex)) {
    // alert("true")
    form.classList.add("valid");
    form.classList.remove("Invalid");
    phonetext.innerHTML = "Your Phone Number is Valid";
    phonetext.style.color = "#00ff00";
    // return true;
  }
  else {
    // alert("message");
    // return false;
    form.classList.add("valid");
    form.classList.remove("invalid");
    phonetext.innerHTML = "Please Enter Valid Phone Number";
    phonetext.style.color = "#ff0000";
  }
}

function zipValidate() { 
  // alert("zip");
  var zipcode = document.getElementById("zipcode");
  var ziptext = document.getElementById("ziptext");
  var form = document.getElementById("form");


  var zipRegex = /[\d]{5}/;

  if(zipcode.value.match(zipRegex)) {
    // alert("true")
    form.classList.add("valid");
    form.classList.remove("Invalid");
    ziptext.innerHTML = "Your zipCode is Valid";
    ziptext.style.color = "#00ff00";
    // return true;
  }
  else {
    // alert("message");
    // return false;
    form.classList.add("valid");
    form.classList.remove("invalid");
    ziptext.innerHTML = "Please Enter Valid Zipcode";
    ziptext.style.color = "#ff0000";
  }
}


function validation(){
  // text.style.color = "#00ff00";


  var form = document.getElementById("form");
  var email = document.getElementById("emailId").value;
  var emailtext = document.getElementById("emailtext");

  // var pattern = /^[^ ]+@northeastern.edu/;
  var pattern = /^[^\[ ]+@northeastern.edu/;
  // var pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

  if (email.match(pattern))
  {
    // alert("ho");
    form.classList.add("valid");
    form.classList.remove("Invalid");
    emailtext.innerHTML = "Your Email Address is Valid";
    emailtext.style.color = "#00ff00";
  }
  else{
    // alert("F")
    form.classList.add("valid");
    form.classList.remove("invalid");
    emailtext.innerHTML = "Please Enter Valid Email";
    emailtext.style.color = "#ff0000";
  }



}








  // var x = document.getElementById("cod");
  // var y = document.getElementById("fifa");
  // var z = document.getElementById("cs");

  // x.addEventListener("change", myFunction);
  // y.addEventListener("change", mySecondFunction);
  // z.addEventListener("change", myThirdFunction);

  // console.log("True");
  


  // function myFunction() {
  //   console.log("True");

  //   // var play = document.getElementById("demo").innerHTML += "Moused over!<br>";
  //   //   selectList.appendChild(play)
  //   console.log("True");


  //   var check = document.createElement("INPUT");
  //   check.setAttribute("type", "checkbox");
  //     console.log("True");
      
  //     selectList.appendChild(check);
      
  
  //     var input = document.createElement("INPUT");
  //     input.setAttribute("type", "text");
      
  //     selectList.appendChild(input);

    
  // }

  // function mySecondFunction() {
  //   console.log("True");

  //   // document.getElementById("demo").innerHTML += "Clicked!<br>";
  //   var check1 = document.createElement("INPUT");
  //   check1.setAttribute("type", "checkbox");
  //     console.log("True");
      
  //     selectList.appendChild(check1);
      
  
  //     var input1 = document.createElement("INPUT");
  //     input1.setAttribute("type", "text");
      
  //     selectList.appendChild(input1);
    
  // }

  // function myThirdFunction() {
  //   console.log("True");

  //   // document.getElementById("demo").innerHTML += "Moused out!<br>";
  //   // selectList.appendChild(x)
  //   var check2 = document.createElement("INPUT");
  //   check2.setAttribute("type", "checkbox");
  //     console.log("True");
      
  //     selectList.appendChild(check2);
      
  
  //     var input2 = document.createElement("INPUT");
  //     input2.setAttribute("type", "text");
      
  //     selectList.appendChild(input2);

  // }
  function Checkbox(evt, dpid){
    // console.log("True");

  
    // console.log("True");
  
    // alert("uadu");
      var x = document.createElement("INPUT");
      x.setAttribute("type", "checkbox");
      x.setAttribute("id", "check");

      var element =  document.getElementById('check');
      if (typeof(element) != 'undefined' && element != null)
      {
        // Exists.
        selectList.removeChild(element);
      }

      // console.log("True");
      
      selectList.appendChild(x)
      
      
  
      var y = document.createElement("p");
      
      y.setAttribute("type", "text");
      y.setAttribute("id", "labeltxt");
      selectList.appendChild(y); 


      // console.log(dpid);

      var e = document.getElementById("games");
      var value = e.value;
      // var text = e.options[e.selectedIndex].text;
      console.log(value);
      if(value=="cod"){
        y.innerText = "This is a COD.";
      } else if(value=="fifa"){
        y.innerText = "This is a Fifa";
      } else if(value=="cs"){
        y.innerText = "This is CS GO";
      } else if(value=="rl"){
        y.innerText = "This is Rocket League";
      } else if (value=="fort"){
        y.innerText = "This is Fortnite";
      } else {
        y.innerText = "Unknown"
      }

      checkbox = document.getElementById('check');

      checkbox.addEventListener('change', e => {
        var newInp = document.createElement("input");
        newInp.setAttribute("type", "text");
        newInp.setAttribute("id", "newLabelText");

        let newValRemove = document.getElementById("newLabelText")
          if(e.target.checked){
              //do something
              selectList.appendChild(newInp); 
          } else {
              console.log("unchecked")
              
              selectList.removeChild(newValRemove);
          }
        
      });

      



      var element2 =  document.getElementById('labeltxt');
      if (typeof(element) != 'undefined' && element2 != null)
      {
        // Exists.
        selectList.removeChild(element2);
      }
      selectList.appendChild(y) 


      // console.log("True");

      

    //  var cod = document.getElementById("cod")
    //  var fifa = document.getElementById("fifa")
    //  if(cod == y.document.getElementById("cod")){
    //   alert("cod");
    //     var codDisplay = document.createElement("p")
    //    codDisplay.innerText = "Add new maps";
    //   selectList.appendChild(codDisplay); 
    //  }
    //  if(fifa == dpid){
    //   alert("fifa");
    //   var fifaDisplay = document.createElement("p");
    //   fifaDisplay.innerText = "Add any players";
    //   selectList.appendChild(fifaDisplay); 
    //  }

     


      
      // selectList.appendChild(y) 

      // console.log("True");

  
  
  
  
  
}


// function GameSelect(evt,cityName ) {
//   // Declare all variables
//   var i, tabcontent, tablinks;

//   // Get all elements with class="tabcontent" and hide them
//     tabcontent = document.getElementsByClassName("tabcontent");
//     for (i = 0; i < tabcontent.length; i++) {
//       alert("none");

//       tabcontent[i].style.display = "none";
//     }

//     // Get all elements with class="tablinks" and remove the class "active"
//     tablinks = document.getElementsByClassName("tablink");
//     for (i = 0; i < tablinks.length; i++) {
//       alert("show");

//       tablinks[i].className = tablinks[i].className.replace(" active", "");
//     }

//     // // Show the current tab, and add an "active" class to the link that opened the tab
//     document.getElementById(cityName).style.display = "block";
//     evt.currentTarget.className += " active";
// }

// function submitFunction(){
//   alert("submit")
//   var frm = document.getElementsByName('formSubmit')[0];
//  frm.submit(); // Submit the form
//  frm.reset();  // Reset all form data
//  return false;
// }


function fnameValid(){
  var fName = document.getElementById('firstName')
  if (fName.value == "" || fName.value == null){
    form.classList.add("valid");
    form.classList.remove("invalid");
    fNametext.innerHTML = "Please Enter Valid Email";
    fNametext.style.color = "#ff0000";

  }

}

function checkValidate(){
  var checkbox = document.getElementsByName("source")
  for(i = 0; i < ele.length; i++) {
    if(checkbox[i].checked){

    }
    else{
      var p = document.createElement('p')
      p.innerHTML("Plz choose")
    }
   
}
}


